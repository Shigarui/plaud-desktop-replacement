"""CLI entry point:  py -m meetingrec <command>"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from datetime import datetime

from .config import Config
from .detector import (
    FILETIME_EPOCH,
    ConsentStoreProbe,
    MeetingDetector,
    MeetingSession,
)
from .storage import build_backend, find_drive_desktop_root

log = logging.getLogger("meetingrec")


def cmd_list(cfg: Config) -> int:
    probe = ConsentStoreProbe()
    entries = probe.read_all(active_only=False)
    if not entries:
        print("No consent-store entries found.")
        return 1
    active_keys = {(u.name, u.started_at) for u in probe.read_all(active_only=True)}
    print(f"{len(entries)} app(s) have used the microphone:\n")
    for u in sorted(entries, key=lambda x: (x.started_at or FILETIME_EPOCH), reverse=True):
        flag = "  <== MIC OPEN NOW" if (u.name, u.started_at) in active_keys else ""
        when = u.started_at.astimezone().strftime("%Y-%m-%d %H:%M:%S") if u.started_at else "never"
        print(f"  [{'pkg' if u.packaged else 'exe'}] {u.name:<40} last start {when}{flag}")
        if u.path:
            print(f"         {u.path}")
    return 0


def cmd_watch(cfg: Config) -> int:
    def on_start(s: MeetingSession) -> None:
        print(f"\n>>> START  #{s.session_id}  {s.app}  {s.started_at.astimezone():%H:%M:%S}")

    def on_stop(s: MeetingSession) -> None:
        print(f"<<< STOP   #{s.session_id}  {str(s.duration).split('.')[0]}  "
              f"apps={','.join(sorted(s.apps_seen))}\n")

    d = MeetingDetector(
        poll_interval=cfg.poll_interval,
        stop_debounce=cfg.stop_debounce,
        allowlist=cfg.allowlist,
        ambiguous=cfg.ambiguous,
        require_playback_for_ambiguous=cfg.require_playback_for_ambiguous,
        on_start=on_start,
        on_stop=on_stop,
    )
    last = ""
    try:
        while True:
            state = d.poll_once()
            holders = ", ".join(str(u) for u in d.qualifying_apps()) or "-"
            line = f"{state:<12} {holders}"
            if line != last:
                print(f"[{datetime.now():%H:%M:%S}] {line}")
                last = line
            time.sleep(cfg.poll_interval)
    except KeyboardInterrupt:
        print("\nstopped")
        return 0


def cmd_storage(cfg: Config) -> int:
    """Verify the archive target before trusting it with a real recording."""
    print(f"backend      : {cfg.backend}")
    print(f"staging dir  : {cfg.staging_dir}  (exists={cfg.staging_dir.exists()})")
    root = find_drive_desktop_root()
    print(f"Drive desktop: {root or 'NOT FOUND'}")
    try:
        backend = build_backend(cfg)
    except Exception as exc:
        print(f"backend init FAILED: {exc}")
        return 1
    print(f"resolved     : {backend.name}")

    probe = cfg.staging_dir / "meetingrec-storage-test.txt"
    probe.write_text(f"written {datetime.now():%Y-%m-%d %H:%M:%S} by meetingrec\n", encoding="utf-8")
    result = backend.archive(probe, "_selftest", {"test": True, "machine": cfg.machine})
    print(f"archive      : {'OK' if result.ok else 'FAILED'}  {result.location or result.error}")
    return 0 if result.ok else 1


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="meetingrec", description="Meeting detection and recording.")
    p.add_argument("command", choices=["list", "watch", "storage"],
                   help="list: mic consent entries | watch: live detection | storage: test archive")
    p.add_argument("-v", "--verbose", action="store_true")
    args = p.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    if sys.platform != "win32":
        print("meetingrec only runs on Windows.", file=sys.stderr)
        return 2

    cfg = Config.load()
    return {"list": cmd_list, "watch": cmd_watch, "storage": cmd_storage}[args.command](cfg)


if __name__ == "__main__":
    raise SystemExit(main())
