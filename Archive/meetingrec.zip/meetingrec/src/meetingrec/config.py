"""
meetingrec.config — per-machine settings.

Reads config.toml from the project root (or $MEETINGREC_CONFIG). That file is
gitignored on purpose: paths and allowlists differ across machines, and the
NAS mount letter is not the same everywhere. config.example.toml is the
committed template.

Design note on paths: capture always writes to `staging_dir` on a local disk.
Never point that at a network share — a Tailscale hiccup mid-call will stall
the writer thread and you will lose audio. Finished files get moved to
`archive_dir` afterward, and that is where the NAS belongs.
"""

from __future__ import annotations

import logging
import os
import tomllib
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config.toml"


@dataclass
class Config:
    # --- detection ---
    poll_interval: float = 2.0
    stop_debounce: float = 45.0
    allowlist: Optional[list[str]] = None  # None -> detector defaults
    ambiguous: Optional[list[str]] = None
    require_playback_for_ambiguous: bool = True

    # --- capture ---
    sample_rate: int = 48000
    preroll_seconds: float = 30.0
    min_session_seconds: float = 60.0  # discard anything shorter

    # --- storage ---
    # backend: "drive" (Drive for Desktop), "driveapi" (API v3), or "local"
    backend: str = "drive"
    staging_dir: Path = field(default_factory=lambda: PROJECT_ROOT / "recordings")
    archive_dir: Optional[Path] = None  # only used by backend = "local"
    group_by: str = "month"  # month | day | flat

    # Drive for Desktop
    drive_folder: str = "Meeting Recordings"
    drive_root: Optional[Path] = None  # auto-detected if unset (e.g. G:/My Drive)

    # Drive API v3 only
    drive_credentials: Path = field(default_factory=lambda: PROJECT_ROOT / "client_secret.json")
    drive_token: Path = field(default_factory=lambda: PROJECT_ROOT / "token.json")
    drive_shared_drive_id: Optional[str] = None

    # --- misc ---
    machine: str = field(default_factory=lambda: os.environ.get("COMPUTERNAME", "unknown"))
    notify_on_start: bool = True

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "Config":
        path = path or Path(os.environ.get("MEETINGREC_CONFIG", DEFAULT_CONFIG_PATH))
        cfg = cls()
        if not path.exists():
            log.info("no config at %s — using defaults", path)
            cfg.staging_dir.mkdir(parents=True, exist_ok=True)
            return cfg

        with path.open("rb") as fh:
            raw: dict[str, Any] = tomllib.load(fh)

        flat: dict[str, Any] = {}
        for section in ("detection", "capture", "storage", "paths", "misc"):
            flat.update(raw.get(section, {}))
        flat.update({k: v for k, v in raw.items() if not isinstance(v, dict)})

        known = {f.name for f in cls.__dataclass_fields__.values()}
        unknown = set(flat) - known
        if unknown:
            log.warning("ignoring unknown config keys: %s", ", ".join(sorted(unknown)))

        for key in ("staging_dir", "archive_dir", "drive_root", "drive_credentials", "drive_token"):
            if flat.get(key):
                flat[key] = Path(str(flat[key])).expanduser()

        cfg = replace(cfg, **{k: v for k, v in flat.items() if k in known})
        cfg.staging_dir.mkdir(parents=True, exist_ok=True)
        log.debug("loaded config from %s", path)
        return cfg
